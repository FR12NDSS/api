const errorHandler = (err, req, res, next) => {
  console.error(`[ERROR]: ${err.message}`)
  const statusCode = err.status || 500
  res.status(statusCode).json({
    error: {
      message: err.message || "Internal Server Error",
      details: err.details || null,
    },
  })
}

export default errorHandler