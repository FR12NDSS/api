-- Pragmatic Play
INSERT INTO games (game_id, name, provider_id, category_id, thumbnail, type, status) VALUES
('pragmatic_wildwest', 'Wild West Gold', 2, 1, 'wildwest.jpg', 'slot', 1),
('pragmatic_sweetbonanza', 'Sweet Bonanza', 2, 1, 'sweetbonanza.jpg', 'slot', 1);

-- Joker Gaming
INSERT INTO games (game_id, name, provider_id, category_id, thumbnail, type, status) VALUES
('joker_caisencheng', 'Caishen Riches', 3, 1, 'caishen.jpg', 'slot', 1),
('joker_threekingdoms', 'Three Kingdoms Quest', 3, 1, 'threekingdoms.jpg', 'slot', 1);

-- Red Tiger
INSERT INTO games (game_id, name, provider_id, category_id, thumbnail, type, status) VALUES
('redtiger_dragonsluck', 'Dragon''s Luck', 4, 1, 'dragonsluck.jpg', 'slot', 1),
('redtiger_piratesplenty', 'Pirates Plenty', 4, 1, 'piratesplenty.jpg', 'slot', 1);