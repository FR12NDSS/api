export const getInfo = (req, res, next) => {
  try {
    res.json({ message: "Fortune Tiger Game Info" })
  } catch (error) {
    next(error)
  }
}

export const spin = (req, res, next) => {
  try {
    res.json({ message: "Fortune Tiger Spin Result" })
  } catch (error) {
    next(error)
  }
}