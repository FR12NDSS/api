export const getInfo = (req, res, next) => {
  try {
    res.json({ message: "Fortune Ox Game Info" })
  } catch (error) {
    next(error)
  }
}

export const spin = (req, res, next) => {
  try {
    res.json({ message: "Fortune Ox Spin Result" })
  } catch (error) {
    next(error)
  }
}