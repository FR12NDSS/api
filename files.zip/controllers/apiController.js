export const launchgame = (req, res) => {
  res.json({ message: "Game launched successfully" })
}

export const getagent = (req, res) => {
  res.json({ message: "Agent data retrieved successfully" })
}

export const attagent = (req, res) => {
  res.json({ message: "Agent attached successfully" })
}