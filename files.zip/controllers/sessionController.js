export const resourcetypeids = (req, res) => {
  res.json({ message: "Resource Type IDs retrieved successfully" })
}

export const verifySession = (req, res) => {
  res.json({ message: "Session verified successfully" })
}