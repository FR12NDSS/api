-- สร้างตาราง games
CREATE TABLE games (
  game_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(100) NOT NULL UNIQUE,
  provider VARCHAR(50) NOT NULL,
  type VARCHAR(50) DEFAULT 'slot',
  thumbnail VARCHAR(255),
  status TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- เพิ่มเกมจากค่าย PGSoft
INSERT INTO games (name, code, provider, type, thumbnail, status) VALUES
('Fortune Tiger', 'fortune_tiger', 'PGSoft', 'slot', '/images/games/pgsoft/fortune_tiger.jpg', 1),
('Fortune Ox', 'fortune_ox', 'PGSoft', 'slot', '/images/games/pgsoft/fortune_ox.jpg', 1),
('Fortune Mouse', 'fortune_mouse', 'PGSoft', 'slot', '/images/games/pgsoft/fortune_mouse.jpg', 1),
('Fortune Rabbit', 'fortune_rabbit', 'PGSoft', 'slot', '/images/games/pgsoft/fortune_rabbit.jpg', 1),
('Mahjong Ways', 'mahjong_ways', 'PGSoft', 'slot', '/images/games/pgsoft/mahjong_ways.jpg', 1),
('Mahjong Ways 2', 'mahjong_ways_2', 'PGSoft', 'slot', '/images/games/pgsoft/mahjong_ways_2.jpg', 1),
('Lucky Neko', 'lucky_neko', 'PGSoft', 'slot', '/images/games/pgsoft/lucky_neko.jpg', 1),
('Ganesha Gold', 'ganesha_gold', 'PGSoft', 'slot', '/images/games/pgsoft/ganesha_gold.jpg', 1),
('Dragon Tiger Luck', 'dragon_tiger_luck', 'PGSoft', 'slot', '/images/games/pgsoft/dragon_tiger_luck.jpg', 1),
('Double Fortune', 'double_fortune', 'PGSoft', 'slot', '/images/games/pgsoft/double_fortune.jpg', 1),
('Jungle Delight', 'jungle_delight', 'PGSoft', 'slot', '/images/games/pgsoft/jungle_delight.jpg', 1),
('Bikini Paradise', 'bikini_paradise', 'PGSoft', 'slot', '/images/games/pgsoft/bikini_paradise.jpg', 1);

-- เพิ่มเกมจากค่าย Pragmatic Play
INSERT INTO games (name, code, provider, type, thumbnail, status) VALUES
('Sweet Bonanza', 'sweet_bonanza', 'PragmaticPlay', 'slot', '/images/games/pragmatic/sweet_bonanza.jpg', 1),
('Gates of Olympus', 'gates_of_olympus', 'PragmaticPlay', 'slot', '/images/games/pragmatic/gates_of_olympus.jpg', 1);

-- เพิ่มเกมจากค่าย Joker
INSERT INTO games (name, code, provider, type, thumbnail, status) VALUES
('Roma', 'roma', 'Joker', 'slot', '/images/games/joker/roma.jpg', 1),
('Horoscope', 'horoscope', 'Joker', 'slot', '/images/games/joker/horoscope.jpg', 1);