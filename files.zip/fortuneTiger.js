export const getInfo = (req, res) => {
  res.json({ message: "Fortune Tiger Game Info" })
}

export const spin = (req, res) => {
  res.json({ message: "Fortune Tiger Spin Result" })
}